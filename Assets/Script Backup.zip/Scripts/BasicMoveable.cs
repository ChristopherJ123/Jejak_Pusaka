﻿using System;
using UnityEngine;

public class BasicMoveable : MonoBehaviour, ITickable, IMoveable
{
    private LayerMask _layerStopsMovement;
    private Transform _movePoint;
    
    public Vector3 StartTickPosition { get; set; }
    public Vector3 EndTickPosition { get; set; }
    public Vector3 LastMoveDir { get; set; }
    public Vector3 ScheduledMoveDir { get; set; }
    public bool IsNextTickScheduled { get; set; }
    public bool IsStartTicking { get; set; }
    public bool IsEndTicking { get; set; }
    
    public bool IsStationary()
    {
        throw new System.NotImplementedException();
    }

    public bool CanMove(Vector3 moveDir)
    {
        throw new System.NotImplementedException();
    }

    public void ScheduleMove(Vector3 moveDir)
    {
        throw new System.NotImplementedException();
    }

    public void DoScheduledMove()
    {
        throw new System.NotImplementedException();
    }

    public void Move(Vector3 moveDir)
    {
        throw new System.NotImplementedException();
    }
    public void OnStartTick(Vector3 playerMoveDir)
    {
        DoScheduledMove();
    }

    public void PostStartTick(Vector3 playerMoveDir)
    {
        StartTickPosition = transform.position;

        // Finished doing scheduled move from OnStartTick
        // Called here so that other Tickable that depends on this variable won't get unexpected result from
        // OnStartTick()'s random ordering.
        if (IsNextTickScheduled)
        {
            IsNextTickScheduled = false;
        }
    }

    public void OnEndTick()
    {
        
    }

    public void PostEndTick()
    {
        EndTickPosition = transform.position;
    }
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _layerStopsMovement = LayerMask.GetMask("Collision");
        
        _movePoint = transform.GetChild(0);
        _movePoint.parent = null;
    }

    private void Update()
    {
        // Animation moving
        if (IsStartTicking)
        {
            transform.position = Vector3.MoveTowards(transform.position, _movePoint.position, 5f * Time.deltaTime);
            if (IsStationary())
            {
                IsStartTicking = false;
            }     
        }
    }
}