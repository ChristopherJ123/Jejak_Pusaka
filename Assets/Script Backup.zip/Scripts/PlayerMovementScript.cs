using System;
using UnityEngine;

public class PlayerMovementScript : MonoBehaviour, ITickable, IMoveable
{
    public static PlayerMovementScript Instance;
    public Transform movePoint;
    public float moveSpeed = 5f;
    
    private bool _postMoveAndTickEnd;
    private float _moveIntervalTimer;

    public Vector3 StartTickPosition { get; set; }
    public Vector3 LastMoveDir { get; set; }
    public bool IsNextTickScheduled { get; set; }
    public Vector3 ScheduledMoveDir { get; set; }

    /// <summary>
    /// Player is idle.
    /// </summary>
    /// <returns>bool</returns>
    public bool IsStationary()
    {
        return Vector3.Distance(transform.position, movePoint.position) == 0;
    }

    /// <summary>
    /// Start a PreStartTickConditions player movement check.
    /// </summary>
    /// <param name="moveDirection">Player move dir</param>
    /// <returns>Check succeed</returns>
    public bool CanMove(Vector3 moveDirection)
    {
        return GameLogic.Instance.PlayerMoveCondition(moveDirection);
    }

    public void ScheduleMove(Vector3 moveDir)
    {
        IsNextTickScheduled = true; // Setting this to true too, so that ice's moveScheduling works with moving a player like a normal player movement.
        
        ScheduledMoveDir = moveDir;
    }

    public void DoScheduledMove()
    {
        if (IsNextTickScheduled)
        {
            Move(ScheduledMoveDir);
            // IsNextTickScheduled = false;
            LastMoveDir = ScheduledMoveDir;
            ScheduledMoveDir = Vector3.zero;
        }
        
    }

    /// <summary>
    /// Move the player directly (recommended check using CanMove() first)
    /// </summary>
    /// <param name="moveDirection"></param>
    public void Move(Vector3 moveDirection)
    {
        // Movement start tick
        IsStartTicking = true;
        movePoint.position += moveDirection;
        LastMoveDir = moveDirection;
    }

    private void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        movePoint.parent = null;
    }

    void Update()
    {
        if (IsStartTicking)
        {
            transform.position = Vector3.MoveTowards(transform.position, movePoint.position, moveSpeed * Time.deltaTime);
            if (IsStationary())
            {
                IsStartTicking = false;
            }
        }

        if (_moveIntervalTimer > 0)
        {
            _moveIntervalTimer -= Time.deltaTime;
        }
        
        if (IsStationary() && !GameLogic.Instance.waitingForAllStartTickToFinish && !GameLogic.Instance.waitingForAllEndTickToFinish)
        {
            if (_postMoveAndTickEnd)
            {
                // Start end tick after moving.
                // GameLogic.Instance.EndTick();
                _postMoveAndTickEnd = false;
                _moveIntervalTimer = 0.1f;
            }

            var moveDirectionInput = new Vector3(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));

            if (!_postMoveAndTickEnd && ((Math.Abs(moveDirectionInput.x) == 1 && moveDirectionInput.y == 0) ||
                               (Math.Abs(moveDirectionInput.y) == 1 && moveDirectionInput.x == 0)
                               ) && !GameLogic.Instance.waitingForAllEndTickToFinish && _moveIntervalTimer <= 0)
            {
                IsNextTickScheduled = true; // Setting this to true so that the CanMove()'s PreStartTick()'s IsPlayerPushing() method works.
                if (CanMove(moveDirectionInput))
                {
                    ScheduleMove(moveDirectionInput);
                    GameLogic.Instance.StartTick(moveDirectionInput);
                }
                else
                {
                    IsNextTickScheduled = false; // False if player cannot move
                    // Future ways may include replacing the isScheduledMoveAndBeforeTickEnd variable and using a
                    // Exception list for the Start Tick's and End Tick's Schedule method, especially for the boulder.
                    // Boulder's tick schedule declines the Crate Tick's method.
                }
                _postMoveAndTickEnd = true;
            }
        }
    }

    public bool IsStartTicking { get; set; }
    public bool IsEndTicking { get; set; }
    public void OnStartTick(Vector3 playerMoveDir)
    {
        // print("Player start tick");
        DoScheduledMove();
    }

    public void PostStartTick(Vector3 playerMoveDir)
    {
        IsNextTickScheduled = false;
    }

    public void OnEndTick()
    {
        // print("Player end tick");
    }

    public void PostEndTick()
    {
        StartTickPosition =
    }
}
